package com.backend.order_ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderManagementMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderManagementMicroserviceApplication.class, args);
	}

}
