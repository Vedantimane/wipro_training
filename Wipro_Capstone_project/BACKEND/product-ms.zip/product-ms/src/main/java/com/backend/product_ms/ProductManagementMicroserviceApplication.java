package com.backend.product_ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductManagementMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductManagementMicroserviceApplication.class, args);
	}

}
